import { useState, type ReactNode } from "react"

type Screen = "today" | "week" | "report" | "setup"
type IconName = "today" | "week" | "report" | "setup" | "chevron" | "edit" | "delete" | "download" | "plus" | "arrow-left" | "arrow-right"

const tags = [
  "Development",
  "Debugging",
  "Learning",
  "Meeting",
  "Documentation",
  "Design",
  "Research",
  "Testing",
  "Admin",
  "Other",
]

type Entry = { time: string; text: string; tags: string[] }
type WeekDay = { day: string; date: string; entries: Entry[] }

const existingEntries: Entry[] = [
  {
    time: "2h 00",
    text: "Connected the Express API to MongoDB",
    tags: ["Development"],
  },
  {
    time: "1h 30",
    text: "Tested the first three routes and fixed CORS errors",
    tags: ["Testing", "Debugging"],
  },
]

const initialWeekDays: WeekDay[] = [
  {
    day: "Mon",
    date: "5 Oct",
    entries: [
      {
        text: "Set up the project repository",
        time: "2h 00",
        tags: ["Development"],
      },
      {
        text: "Read the Express documentation",
        time: "3h 00",
        tags: ["Learning"],
      },
    ],
  },
  {
    day: "Tue",
    date: "6 Oct",
    entries: [
      {
        text: "Built the Express server",
        time: "3h 15",
        tags: ["Development"],
      },
      {
        text: "Daily team sync",
        time: "1h 30",
        tags: ["Meeting"],
      },
    ],
  },
  { day: "Wed", date: "7 Oct", entries: existingEntries },
  { day: "Thu", date: "8 Oct", entries: [] },
  { day: "Fri", date: "9 Oct", entries: [] },
]

function durationToMinutes(duration: string) {
  const match = duration.match(/(\d+)h\s*(\d+)/)
  return match ? Number(match[1]) * 60 + Number(match[2]) : 0
}

function formatMinutes(minutes: number) {
  return `${Math.floor(minutes / 60)}h ${String(minutes % 60).padStart(2, "0")}`
}

function getDayTotal(day: WeekDay) {
  return day.entries.reduce(
    (total, entry) => total + durationToMinutes(entry.time),
    0,
  )
}

function getWeekTotal(days: WeekDay[]) {
  return days.reduce((total, day) => total + getDayTotal(day), 0)
}

function getTagTotals(days: WeekDay[]) {
  const totals: Record<string, number> = {}
  days.forEach((day) =>
    day.entries.forEach((entry) => {
      const primaryTag = entry.tags[0] || "Other"
      totals[primaryTag] =
        (totals[primaryTag] || 0) + durationToMinutes(entry.time)
    }),
  )
  return totals
}

function Icon({ name, size = 18 }: { name: IconName size?: number }) {
  const paths: Record<IconName, ReactNode> = {
    today: (
      <>
        <rect x="3" y="5" width="18" height="16" rx="2" />
        <path d="M16 3v4M8 3v4M3 10h18M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01" />
      </>
    ),
    week: (
      <>
        <path d="M4 5h16v15H4zM8 3v4M16 3v4M4 9h16" />
        <path d="M8 13h2M14 13h2M8 17h2M14 17h2" />
      </>
    ),
    report: (
      <>
        <path d="M6 3h9l4 4v14H6zM15 3v5h4M9 12h6M9 16h6" />
      </>
    ),
    setup: (
      <>
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21h-4v-.09A1.7 1.7 0 0 0 8.6 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-1.6-1H3v-4h.09A1.7 1.7 0 0 0 4.6 9a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-1.6V3h4v.09A1.7 1.7 0 0 0 15 4.6a1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 19.4 9c.12.37.33.7.6 1h1v4h-.09a1.7 1.7 0 0 0-1.51 1Z" />
      </>
    ),
    chevron: <path d="m8 10 4 4 4-4" />,
    edit: (
      <>
        <path d="m14 5 5 5M4 20l3.5-.5L19 8a2.1 2.1 0 0 0-3-3L4.5 16.5z" />
      </>
    ),
    delete: (
      <>
        <path d="M4 7h16M9 3h6l1 4H8zM7 7l1 14h8l1-14M10 11v6M14 11v6" />
      </>
    ),
    download: <path d="M12 3v12m0 0 4-4m-4 4-4-4M5 20h14" />,
    plus: <path d="M12 5v14M5 12h14" />,
    "arrow-left": <path d="m15 18-6-6 6-6" />,
    "arrow-right": <path d="m9 18 6-6-6-6" />,
  }
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  )
}

function Logo() {
  return (
    <div className="logo" aria-label="Jotern">
      <span className="logo-tile">
        <svg width="36" height="36" viewBox="0 0 96 96" aria-hidden="true">
          <rect
            x="2"
            y="2"
            width="92"
            height="92"
            rx="24"
            fill="#1B2A5C"
          />
          <path
            d="M55 38 V62 C55 73 47 77 38 72"
            fill="none"
            stroke="#F3F5FA"
            strokeWidth="11"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="55" cy="22" r="7.5" fill="#FFD84A" />
        </svg>
      </span>
      <span className="logo-word">
        <span className="logo-highlight">jot</span>ern
      </span>
    </div>
  )
}

function Sidebar({
  screen,
  onNavigate,
}: {
  screen: Screen
  onNavigate: (screen: Screen) => void
}) {
  const items: { id: Screen label: string icon: IconName }[] = [
    { id: "today", label: "Today", icon: "today" },
    { id: "week", label: "Week", icon: "week" },
    { id: "report", label: "Report", icon: "report" },
    { id: "setup", label: "Setup", icon: "setup" },
  ]
  return (
    <aside className="sidebar">
      <Logo />
      <nav className="nav" aria-label="Primary navigation">
        {items.map((item) => (
          <button
            key={item.id}
            className={`nav-item ${screen === item.id ? "active" : ""}`}
            onClick={() => onNavigate(item.id)}
          >
            <Icon name={item.icon} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
      <div className="offline-status">
        <span className="offline-dot" />
        <span>Offline. Saved on this laptop.</span>
      </div>
    </aside>
  )
}

function Button({
  children,
  variant = "primary",
  onClick,
  icon,
  type = "button",
}: {
  children: ReactNode
  variant?: "primary" | "secondary" | "ghost"
  onClick?: () => void
  icon?: IconName
  type?: "button" | "submit"
}) {
  return (
    <button className={`button ${variant}`} onClick={onClick} type={type}>
      {icon && <Icon name={icon} size={17} />}
      {children}
    </button>
  )
}

function Chip({
  children,
  selected = false,
  onClick,
}: {
  children: ReactNode
  selected?: boolean
  onClick?: () => void
}) {
  return (
    <button
      type="button"
      className={`chip ${selected ? "selected" : ""}`}
      onClick={onClick}
    >
      {children}
    </button>
  )
}

function TimeBars({ totals }: { totals: Record<string, number> }) {
  const colors = ["ink", "yellow", "pencil", "line"]
  const items = Object.entries(totals).sort(([, a], [, b]) => b - a)
  const max = Math.max(...items.map(([, value]) => value), 1)

  if (items.length === 0) {
    return <p className="stat-empty">No time by tag yet.</p>
  }

  return (
    <div className="mini-bars">
      {items.slice(0, 4).map(([label, value], index) => (
        <div className="mini-bar-row" key={label}>
          <span>{label}</span>
          <span className="bar-track">
            <span
              className={`bar-fill ${colors[index]}`}
              style={{ width: `${(value / max) * 100}%` }}
            />
          </span>
          <span className="mono">{formatMinutes(value)}</span>
        </div>
      ))}
    </div>
  )
}

function StatCard({
  label,
  children,
  className = "",
}: {
  label: string
  children: ReactNode
  className?: string
}) {
  return (
    <section className={`card stat-card ${className}`}>
      <div className="eyebrow">{label}</div>
      {children}
    </section>
  )
}

function EntryCard({
  entry,
}: {
  entry: { time: string text: string tags: string[] }
}) {
  return (
    <article className="entry-card">
      <div className="entry-top">
        <span className="entry-time mono">{entry.time}</span>
        <div className="entry-actions">
          <button aria-label="Edit entry">
            <Icon name="edit" size={16} />
          </button>
          <button aria-label="Delete entry">
            <Icon name="delete" size={16} />
          </button>
        </div>
      </div>
      <p>{entry.text}</p>
      <div className="entry-tags">
        {entry.tags.map((tag) => (
          <span className="tag" key={tag}>
            {tag}
          </span>
        ))}
      </div>
    </article>
  )
}

function JotForm({
  onAdd,
}: {
  onAdd: (entry: { time: string text: string tags: string[] }) => void
}) {
  const [text, setText] = useState("")
  const [hours, setHours] = useState("")
  const [minutes, setMinutes] = useState("")
  const [selected, setSelected] = useState<string[]>(["Development"])
  const [detailsOpen, setDetailsOpen] = useState(false)
  const [showError, setShowError] = useState(false)

  function toggleTag(tag: string) {
    setSelected((current) =>
      current.includes(tag)
        ? current.filter((item) => item !== tag)
        : [...current, tag],
    )
  }

  function submit() {
    if (!hours && !minutes) {
      setShowError(true)
      return
    }
    onAdd({
      time: `${hours || "0"}h ${minutes.padStart(2, "0") || "00"}`,
      text: text || "Worked on today’s internship tasks",
      tags: selected.length ? selected : ["Other"],
    })
    setText("")
    setHours("")
    setMinutes("")
    setShowError(false)
  }

  return (
    <section className="card jot-card">
      <div className="section-heading">
        <div>
          <h2>Jot today</h2>
          <p>One minute now saves an hour on Friday.</p>
        </div>
        <span className="autosave">Saved locally</span>
      </div>
      <div className="form-grid">
        <label className="field full">
          <span>Date</span>
          <input value="Wed 7 Oct 2026" readOnly className="mono" />
        </label>
        <label className="field full">
          <span>What I did</span>
          <textarea
            rows={3}
            value={text}
            onChange={(event) => setText(event.target.value)}
            placeholder="One clear line is enough."
          />
        </label>
        <div className="field full">
          <span>Time spent</span>
          <div className="time-inputs">
            <label>
              <input
                value={hours}
                onChange={(event) => {
                  setHours(event.target.value)
                  setShowError(false)
                }}
                inputMode="numeric"
                placeholder="0"
              />
              <span>hours</span>
            </label>
            <label>
              <input
                value={minutes}
                onChange={(event) => {
                  setMinutes(event.target.value)
                  setShowError(false)
                }}
                inputMode="numeric"
                placeholder="00"
              />
              <span>minutes</span>
            </label>
          </div>
          {showError && (
            <div className="field-error">
              Add the time spent so the week adds up.
            </div>
          )}
        </div>
        <div className="field full">
          <span>Tags</span>
          <div className="chip-list">
            {tags.map((tag) => (
              <Chip
                key={tag}
                selected={selected.includes(tag)}
                onClick={() => toggleTag(tag)}
              >
                {tag}
              </Chip>
            ))}
          </div>
        </div>
      </div>
      <button
        className={`details-toggle ${detailsOpen ? "open" : ""}`}
        type="button"
        onClick={() => setDetailsOpen(!detailsOpen)}
      >
        <span>Difficulty, solution, lesson</span>
        <Icon name="chevron" />
      </button>
      {detailsOpen && (
        <div className="details-fields">
          <label className="field">
            <span>Difficulty</span>
            <input placeholder="What slowed me down?" />
          </label>
          <label className="field">
            <span>How I solved it</span>
            <input placeholder="What worked?" />
          </label>
          <label className="field">
            <span>What I learned</span>
            <input placeholder="What will I reuse?" />
          </label>
        </div>
      )}
      <div className="form-footer">
        <span>Keep it rough. You can edit it later.</span>
        <Button onClick={submit}>Jot today</Button>
      </div>
    </section>
  )
}

function TodayScreen({
  entries,
  weekDays,
  onAdd,
}: {
  entries: Entry[]
  weekDays: WeekDay[]
  onAdd: (entry: Entry) => void
}) {
  const isEmpty = entries.length === 0
  const weekTotal = getWeekTotal(weekDays)
  const daysLogged = weekDays.filter((day) => getDayTotal(day) > 0).length
  const tagTotals = getTagTotals(weekDays)
  return (
    <>
      <header className="page-header">
        <div>
          <div className="kicker">YOUR WORKDAY</div>
          <h1>Today · Wed 7 Oct 2026</h1>
        </div>
        <p className="tagline">Jot it daily. Hand it in weekly.</p>
      </header>
      <div className="stats-grid">
        <StatCard label="This week">
          <div className="number-line">
            <strong>{formatMinutes(weekTotal)}</strong>
            <span>of 40h</span>
          </div>
        </StatCard>
        <StatCard label="Days logged in a row">
          <div className="number-line">
            <strong>{daysLogged}</strong>
            <span>{daysLogged === 0 ? "Start today" : "Keep going"}</span>
          </div>
        </StatCard>
        <StatCard label="Time by tag" className="wide-stat">
          <TimeBars totals={tagTotals} />
        </StatCard>
        <StatCard label="Latest difficulty" className="wide-stat">
          {weekTotal === 0 ? (
            <p className="stat-empty">No difficulties logged yet.</p>
          ) : (
            <>
              <h3>CORS errors</h3>
              <p className="muted">
                Solved · set the origin once in middleware
              </p>
            </>
          )}
        </StatCard>
      </div>
      <div className="today-columns">
        <JotForm onAdd={onAdd} />
        <section className="entries-column">
          <div className="entries-heading">
            <div>
              <h2>Today’s entries</h2>
              <p>
                {entries.length} {entries.length === 1 ? "entry" : "entries"} ·
                7 Oct
              </p>
            </div>
          </div>
          {isEmpty ? (
            <div className="card empty-state">
              <span className="empty-rule" />
              <h3>Nothing jotted yet.</h3>
              <p>Start with one line.</p>
            </div>
          ) : (
            <div className="entry-list">
              {entries.map((entry, index) => (
                <EntryCard entry={entry} key={`${entry.text}-${index}`} />
              ))}
            </div>
          )}
        </section>
      </div>
    </>
  )
}

function MarkdownPanel({
  days,
  onClose,
}: {
  days: WeekDay[]
  onClose: () => void
}) {
  const wednesday = days.find((day) => day.day === "Wed")!
  const wedLines = wednesday.entries
    .map((entry) => `- ${entry.text}`)
    .join("\n")
  return (
    <aside className="preview-panel">
      <div className="preview-header">
        <div>
          <span className="eyebrow">MARKDOWN PREVIEW</span>
          <h2>week-41.md</h2>
        </div>
        <button
          onClick={onClose}
          aria-label="Close preview"
          className="close-button"
        >
          ×
        </button>
      </div>
      <pre>{`## Week 41 (5 to 9 Oct 2026)

### Wed 7 Oct · ${formatMinutes(getDayTotal(wednesday))}

${wedLines || "- Not yet."}
- Difficulty: CORS errors
- Lesson: set the origin once, in middleware

**Total: ${formatMinutes(getWeekTotal(days))}**`}</pre>
      <div className="preview-footer">
        <span>Ready to hand in.</span>
        <Button icon="download">Download .md</Button>
      </div>
    </aside>
  )
}

function WeekScreen({
  days,
  onBuildReport,
}: {
  days: WeekDay[]
  onBuildReport: () => void
}) {
  const [exported, setExported] = useState(false)
  const weekTotal = getWeekTotal(days)
  const daysLogged = days.filter((day) => getDayTotal(day) > 0).length
  const tagTotals = getTagTotals(days)
  const legendColors: Record<string, string> = {
    Development: "dev",
    Learning: "learning",
    Meeting: "meeting",
    Documentation: "docs",
    Testing: "testing",
  }
  return (
    <>
      <header className="page-header week-header">
        <div>
          <div className="kicker">WEEKLY LOG</div>
          <div className="title-with-arrows">
            <button aria-label="Previous week">
              <Icon name="arrow-left" />
            </button>
            <h1>Week 41 · 5 to 9 Oct 2026</h1>
            <button aria-label="Next week">
              <Icon name="arrow-right" />
            </button>
          </div>
        </div>
        <div className="header-actions">
          <Button variant="secondary" onClick={onBuildReport}>
            Build report outline
          </Button>
          <Button onClick={() => setExported(true)} icon="download">
            Export week
          </Button>
        </div>
      </header>
      <section className="card week-summary">
        <div className="summary-total">
          <span className="eyebrow">TOTAL THIS WEEK</span>
          <strong>{formatMinutes(weekTotal)}</strong>
          <span>{daysLogged} days logged</span>
        </div>
        <div className="summary-chart">
          <div className="stacked-bar">
            {Object.entries(tagTotals).map(([label, minutes]) => (
              <span
                className={`stack ${legendColors[label] || "docs"}`}
                style={{
                  width: `${weekTotal ? (minutes / weekTotal) * 100 : 0}%`,
                }}
                key={label}
              />
            ))}
          </div>
          <div className="legend">
            {Object.entries(tagTotals).map(([label, minutes]) => (
              <span key={label}>
                <i className={legendColors[label] || "docs"} /> {label}{" "}
                <b>{formatMinutes(minutes)}</b>
              </span>
            ))}
          </div>
        </div>
      </section>
      <div className="week-grid">
        {days.map((day) => (
          <section
            className={`day-column ${day.day === "Wed" ? "current" : ""}`}
            key={day.day}
          >
            <div className="day-heading">
              <div>
                <span>{day.day}</span>
                <small>{day.date}</small>
              </div>
              <strong className="mono">
                {formatMinutes(getDayTotal(day))}
              </strong>
            </div>
            <div className="day-entries">
              {day.entries.length === 0 ? (
                <p className="not-yet">Not yet.</p>
              ) : (
                day.entries.map((entry) => (
                  <article className="compact-entry" key={entry.text}>
                    <time className="mono">{entry.time}</time>
                    <p>{entry.text}</p>
                    <span className="tag">{entry.tags[0]}</span>
                  </article>
                ))
              )}
            </div>
            <button className="add-entry">
              <Icon name="plus" size={15} /> Add entry
            </button>
          </section>
        ))}
      </div>
      {exported && (
        <>
          <div className="panel-scrim" onClick={() => setExported(false)} />
          <MarkdownPanel days={days} onClose={() => setExported(false)} />
          <div className="toast">
            <span className="toast-mark">✓</span>
            Week 41 exported to Markdown.
          </div>
        </>
      )}
    </>
  )
}

function ReportScreen() {
  const [built, setBuilt] = useState(false)
  return (
    <>
      <header className="page-header">
        <div>
          <div className="kicker">INTERNSHIP REPORT</div>
          <h1>Report outline</h1>
        </div>
        <div className="header-actions">
          {built && (
            <Button variant="secondary" icon="download">
              Download .md
            </Button>
          )}
          <Button onClick={() => setBuilt(true)}>Build report outline</Button>
        </div>
      </header>
      <section className="card template-card">
        <div className="template-icon">
          <Icon name="report" size={22} />
        </div>
        <div>
          <div className="template-title">
            <h2>Template</h2>
            <span className="default-chip">Default</span>
          </div>
          <strong>ENSPD — Rapport de stage ouvrier</strong>
          <p>
            Your report is built from your daily logs. You only write the parts
            the logs can’t know.
          </p>
        </div>
      </section>
      <section className="card outline-card">
        <div className="outline-header">
          <div>
            <span className="eyebrow">GENERATED OUTLINE</span>
            <h2>rapport-de-stage.md</h2>
          </div>
          <div className="outline-key">
            <span>
              <i className="filled-key" /> From your logs
            </span>
            <span>
              <i className="todo-key" /> To write
            </span>
          </div>
        </div>
        <div className="outline-document mono">
          <div className="outline-section filled">
            <h3># Page de garde</h3>
            <p>Stagiaire: Amélie Nguema</p>
            <p>Entreprise: Studio Exemple · ENSPD</p>
            <p>5 octobre — 18 décembre 2026</p>
          </div>
          <div className="outline-section todo">
            <h3>## Introduction</h3>
            <p>
              [To write] Why you chose this internship and what you expected.
            </p>
          </div>
          <div className="outline-section todo">
            <h3>## Première partie — Présentation de l’entreprise</h3>
            <p>
              [To write] History, activities, structure and your department.
            </p>
          </div>
          <div className="outline-section filled">
            <h3>## Deuxième partie — Déroulement du stage</h3>
            <p>### Calendrier par semaine</p>
            <p>Week 41 · API setup, MongoDB connection, route testing</p>
            <p>### Tâches par semaine</p>
            <p>
              Built the Express server · Documented endpoints · Wrote
              integration tests
            </p>
          </div>
          <div className="outline-section filled">
            <h3>## Troisième partie — Acquis du stage</h3>
            <p>### Compétences acquises</p>
            <p>
              Express routing · MongoDB · API testing · Technical documentation
            </p>
            <p>### Difficultés et solutions</p>
            <p>CORS errors — set the origin once, in middleware.</p>
          </div>
          <div className="outline-section todo">
            <h3>## Conclusion</h3>
            <p>[To write] Sum up the experience and what comes next.</p>
          </div>
        </div>
      </section>
      {built && (
        <div className="toast">
          <span className="toast-mark">✓</span>
          Outline built from your ENSPD template.
        </div>
      )}
    </>
  )
}

function SetupScreen({ onStart }: { onStart: () => void }) {
  const [editableTags, setEditableTags] = useState(tags)
  return (
    <>
      <header className="page-header">
        <div>
          <div className="kicker">FIRST RUN</div>
          <h1>Set up your internship</h1>
        </div>
        <p className="tagline">Five details. Then you’re ready.</p>
      </header>
      <section className="card setup-card">
        <div className="setup-intro">
          <span className="step-count">01</span>
          <div>
            <h2>The basics</h2>
            <p>Used in your weekly exports and report outline.</p>
          </div>
        </div>
        <div className="setup-fields">
          <label className="field">
            <span>Company</span>
            <input defaultValue="Studio Exemple" />
          </label>
          <label className="field">
            <span>Supervisor</span>
            <input defaultValue="Yann Mbarga" />
          </label>
          <label className="field">
            <span>School</span>
            <input defaultValue="ENSPD" />
          </label>
          <label className="field">
            <span>Start date</span>
            <input className="mono" defaultValue="05 Oct 2026" />
          </label>
          <label className="field">
            <span>End date</span>
            <input className="mono" defaultValue="18 Dec 2026" />
          </label>
        </div>
        <div className="setup-divider" />
        <div className="setup-tags">
          <div className="setup-intro">
            <span className="step-count">02</span>
            <div>
              <h2>Your tags</h2>
              <p>Use these to see where your time goes.</p>
            </div>
          </div>
          <div className="editable-tags">
            {editableTags.map((tag) => (
              <button
                className="editable-chip"
                key={tag}
                onClick={() =>
                  setEditableTags(editableTags.filter((item) => item !== tag))
                }
                title="Remove tag"
              >
                {tag} <span>×</span>
              </button>
            ))}
            <button
              className="add-tag"
              onClick={() =>
                !editableTags.includes("Communication") &&
                setEditableTags([...editableTags, "Communication"])
              }
            >
              <Icon name="plus" size={15} /> Add a tag
            </button>
          </div>
        </div>
        <div className="setup-footer">
          <p>You can change all of this later in Setup.</p>
          <Button onClick={onStart}>Start jotting</Button>
        </div>
      </section>
    </>
  )
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("today")
  const [weekDays, setWeekDays] = useState(initialWeekDays)
  const todayEntries = weekDays.find((day) => day.day === "Wed")!.entries

  function startJotting() {
    setWeekDays((days) => days.map((day) => ({ ...day, entries: [] })))
    setScreen("today")
  }

  function addTodayEntry(entry: Entry) {
    setWeekDays((days) =>
      days.map((day) =>
        day.day === "Wed"
          ? { ...day, entries: [...day.entries, entry] }
          : day,
      ),
    )
  }

  return (
    <div className="app-shell">
      <Sidebar screen={screen} onNavigate={setScreen} />
      <main className="main-content">
        {screen === "today" && (
          <TodayScreen
            entries={todayEntries}
            weekDays={weekDays}
            onAdd={addTodayEntry}
          />
        )}
        {screen === "week" && (
          <WeekScreen
            days={weekDays}
            onBuildReport={() => setScreen("report")}
          />
        )}
        {screen === "report" && <ReportScreen />}
        {screen === "setup" && <SetupScreen onStart={startJotting} />}
      </main>
    </div>
  )
}
